#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h> /* wait */
#include "readcmd.h"

void printDir() { 
   char cwd[1024]; 
   getcwd(cwd, sizeof(cwd)); 
   printf("%s$ ", cwd); 
}

void cd(char ***input) { 
   if(input[0][1] == NULL){
      chdir("/home");
   }
   else {
      if (chdir(input[0][1]) == -1) {
         perror("Aucun répertoire de ce nom");
      }
   } 
}

void afficher_commande(char ***command){
   //printf("%s ", command[0][0]);
   //printf("test5");
   int i = 0;
   //printf("test6");
   int j = 0;
   //printf("test1");
   while(command[i] != NULL){
      //printf("test2");
      while(command[i][j] != NULL){
            //printf("test");
            printf("%s ", command[i][j]);
      j = j + 1;
      }				
   i = i + 1;
	}
}

int main(int argc, char *argv[]) {
   struct cmdline *cmd;
   pid_t pidFils, idFils;
   int codeTerm;

   typedef struct processus{
		int id_shell;
		pid_t pid;
		int bg_flag;
		char ***command;
		int ended;
	}p;

   p jobs[1000];
	int nb_jobs = 0;

   void ajouter_job(pid_t pid, int bg_flag, char ***command) {
		jobs[nb_jobs].id_shell = nb_jobs;
		jobs[nb_jobs].pid = pid;
		jobs[nb_jobs].bg_flag = bg_flag;
		jobs[nb_jobs].command = command;
		jobs[nb_jobs].ended = 0;
      nb_jobs = nb_jobs + 1;
	}

   void list(p jobs[], int nb_jobs) {
		printf("Affichage de jobs :\n");
  		printf("%-10s%-10s%-10s%-10s\n","ID_SHELL", "PID", "BG(1/0)", "COMMANDE");
		for(int i = 0; i < nb_jobs; i = i+1 ){
      		if (jobs[i].ended == 1){
      			continue;
      		}
      		else{
      			printf("%-10d%-10d%-10d", jobs[i].id_shell, jobs[i].pid, jobs[i].bg_flag);
      			printf("\n");
     		} 			
    	}
	}

   while(1) {
      printDir();
      printf("%d ",getpid());
      fflush(stdout);
      cmd = readcmd();
      if(*(cmd->seq) != NULL) {
         //Commandes internes
         //exit
         if(strcmp("exit", cmd->seq[0][0]) == 0){
            break;
         }
         //cd
         else if(strcmp("cd", cmd->seq[0][0]) == 0){
            cd(cmd->seq);
         }
         //list
         else if(strcmp("list", cmd->seq[0][0]) == 0){
            printf("%s\n", cmd->seq[0][0]);
            list(jobs, nb_jobs);
         }
         //Commandes générales
         else {
            pidFils = fork();
            if (pidFils == -1) {
               printf("Erreur fork\n");
               exit(1);
            } else if (pidFils == 0) { /*fils*/
               //premier parametre la commande tandis que le deuxième c'est la commande complete
               if (execvp(cmd->seq[0][0], cmd->seq[0]) < 0) {
                  perror("La commande n'a pu être exécuté (execvp)"); 
                  exit (EXIT_FAILURE);
               }
            } else { /*pere*/
               int bg;
               //printf("processus %d (pere), de pere %d\n", getpid(), getppid ());
               //printf("processus %d (p`ere), de p`ere %d\n", getpid(), getppid ());
               if((cmd->backgrounded) != NULL) {
                  bg = 1;
                  ajouter_job(pidFils, bg, cmd->seq);
                  //CREER UN DECALAGE A REGLER
                  continue;
               } else {
                  bg = 0;
                  ajouter_job(pidFils, bg, cmd->seq);
                  idFils=wait(&codeTerm);
               }
               if (idFils  ==  -1) {
                  perror("wait ");
                  exit (2);
               }
               if (WIFEXITED(codeTerm )) {
                  //printf("[%d] fin fils %d par exit %d\n",codeTerm ,idFils ,WEXITSTATUS(codeTerm ));
               } else {
                  //printf("[%d] fin fils %d par signal %d\n",codeTerm ,idFils ,WTERMSIG(codeTerm ));
               }
            }
         }
      }
   }
   return EXIT_SUCCESS;
}par le